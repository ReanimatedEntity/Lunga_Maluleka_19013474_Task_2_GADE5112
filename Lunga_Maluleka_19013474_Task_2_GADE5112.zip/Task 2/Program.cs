﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_1
{
    abstract class Tile
    {
        protected int X;
        protected int Y;

        public enum TileType
        {
            Hero,Enemy,Gold,Weapon
        }

        public int x { get => X; set => X; value; }
        public int y { get => Y; set => Y; value; }
    }

    public Tile(int X, int Y)


